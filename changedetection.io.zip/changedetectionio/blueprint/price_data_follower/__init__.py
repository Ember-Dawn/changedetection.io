
from changedetectionio.strtobool import strtobool
from flask import Blueprint, flash, redirect, url_for
from changedetectionio.auth_decorator import login_optionally_required
from changedetectionio.store import ChangeDetectionStore
from changedetectionio import queuedWatchMetaData
from changedetectionio import worker_pool
from queue import PriorityQueue

PRICE_DATA_TRACK_ACCEPT = 'accepted'
PRICE_DATA_TRACK_REJECT = 'rejected'

def construct_blueprint(datastore: ChangeDetectionStore, update_q: PriorityQueue):

    price_data_follower_blueprint = Blueprint('price_data_follower', __name__)

    @price_data_follower_blueprint.route("/<uuid_str:uuid>/accept", methods=['POST'])
    @login_optionally_required
    def accept(uuid):
        datastore.data['watching'][uuid]['track_ldjson_price_data'] = PRICE_DATA_TRACK_ACCEPT
        datastore.data['watching'][uuid]['processor'] = 'restock_diff'
        datastore.data['watching'][uuid].clear_watch()
        datastore.data['watching'][uuid].commit()
        worker_pool.queue_item_async_safe(update_q, queuedWatchMetaData.PrioritizedItem(priority=1, item={'uuid': uuid}))
        return redirect(url_for("watchlist.index"))

    @price_data_follower_blueprint.route("/<uuid_str:uuid>/reject", methods=['POST'])
    @login_optionally_required
    def reject(uuid):
        datastore.data['watching'][uuid]['track_ldjson_price_data'] = PRICE_DATA_TRACK_REJECT
        datastore.data['watching'][uuid].commit()
        return redirect(url_for("watchlist.index"))


    return price_data_follower_blueprint


